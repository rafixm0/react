export * from './getHeroById';
export * from './getHeroesByName';
export * from './getHeroesByPublisher';