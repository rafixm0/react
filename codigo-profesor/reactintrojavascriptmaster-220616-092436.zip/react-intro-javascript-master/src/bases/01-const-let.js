
// Variables y Constantes

const nombre = 'Fernando';
const apellido = 'Herrera';

let valorDado = 5;
valorDado = 4;

console.log( nombre, apellido, valorDado )

// var No se debe de usar...
if ( true ) {
    const nombre = 'Peter';
    console.log(nombre)
}

console.log( valorDado );

